НЯШКА — Android-проект

Это Android-приложение-оболочка: оно открывает сайт Няшка внутри WebView.
HTML уже включён в приложение и доступен локально. Сам чат работает в демо-режиме,
подключения к настоящей ИИ-модели/API пока нет.

СБОРКА APK В ANDROID STUDIO
1. Установи Android Studio на компьютер.
2. Распакуй архив NyashkaAndroid.zip.
3. В Android Studio выбери Open и укажи папку NyashkaAndroid.
4. Дождись Gradle Sync и установки Android SDK 35, если Android Studio попросит.
5. Открой Build → Build Bundle(s) / APK(s) → Build APK(s).
6. APK появится в app/build/outputs/apk/debug/app-debug.apk.

СБОРКА ЧЕРЕЗ GITHUB ACTIONS
1. Создай GitHub-репозиторий и загрузи туда содержимое этой папки.
2. Открой вкладку Actions.
3. Выбери workflow "Build Nyashka APK" и нажми Run workflow.
4. После завершения скачай артефакт Nyashka-debug-apk — внутри будет app-debug.apk.

Минимальная версия Android: 6.0 (API 23).
Имя приложения: Няшка.
Пакет: ru.nyashka.app.
